import './login.scss';
import Input from '../../controls/input/input';
import Button from './../../controls/button/button';
import { useState } from 'react';
import login from '../../../services/auth/login';

export default function Login(){

    const [user, setuser] = useState({
        email: "",
        password:""
    })

    function handlerSubmit(event){
        event.preventDefault();


        login(user, (isLogin, data, mes_error)=>{
            if(isLogin){
                console.log(data);
            }
            else alert(mes_error)
        })

    }

    return (
        <div className="login">
            <form onSubmit={handlerSubmit}>
                      
                <Input value={user.email} type="email" title='Email' handlerChange={({target})=> {
                    setuser({...user, email: target.value})
                }}/>
                <Input value={user.password}   title='Password' type="password" handlerChange={({target})=> {
                    setuser({...user, password: target.value})
                }}/>

                <Button txt="Login" handlerClick={()=> {}}></Button>
            </form>

        </div>
    )
}