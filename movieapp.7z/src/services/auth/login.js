import firebase from "firebase";



export default function login({email, password}, callback) {
    firebase
    .auth()
    .signInWithEmailAndPassword(email, password)
    .then((data) => {
    // Signed in
    var user = data;
    // ...
    console.log(user);
  })
  .catch((error) => {
    callback(false, null)
  });
}